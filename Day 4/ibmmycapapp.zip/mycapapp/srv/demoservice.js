module.exports = (cds) => {
    cds.on ('spiderman', req => `Hello  ${req.data.to}!`)
}