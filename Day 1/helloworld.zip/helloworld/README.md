# helloworld

[![Build Status](https://cloud.drone.io/api/badges/go-training/helloworld/status.svg)](https://cloud.drone.io/go-training/helloworld)

Hello World for Golang

## Simple Command

Run golang program

```bash
go run main.go
```

Testing

```bash
go test
```

Build binary

```bash
go build
```

Install binary

```bash
go install
```
